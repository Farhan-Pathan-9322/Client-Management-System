package stepdefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.LoginPage;

public class LoginSteps {
    private WebDriver driver;
    private LoginPage loginPage;

    @Given("the user is on the login page")
    public void userOnLoginPage() {
        if (driver == null) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
        loginPage = new LoginPage(driver);
        loginPage.navigateToLogin("http://localhost:4200/login"); // Pass the login URL
    }

    @When("the user enters valid email {string} and password {string}")
    public void userEntersCredentials(String email, String password) {
        try {
            loginPage.enterCredentials(email, password);
        } catch (Exception e) {
            throw new RuntimeException("Error entering credentials: " + e.getMessage());
        }
    }

    @Then("the user should see the message {string}")
    public void userSeesSuccessMessage(String message) {
        try {
            assertEquals("Success message does not match!", message, loginPage.getSuccessMessage());
        } catch (Exception e) {
            throw new RuntimeException("Error verifying success message: " + e.getMessage());
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    @When("the user leaves email and password fields blank")
    public void userLeavesFieldsBlank() {
        WebElement loginButton = driver.findElement(By.id("loginButton"));
        loginButton.click();
    }

    @Then("the user should see an error message {string}")
    public void userSeesBlankFieldErrorMessage(String message) {
        String errorMessage = driver.findElement(By.id("errorMessage")).getText();
        assertEquals(message, errorMessage);
    }

    // For the invalid credentials scenario
    @When("the user enters invalid email {string} and password {string}")
    public void userEntersInvalidCredentials(String email, String password) {
        try {
            loginPage.enterCredentials(email, password);
        } catch (Exception e) {
            throw new RuntimeException("Error entering invalid credentials: " + e.getMessage());
        }
    }

    @Then("the user should see an error message {string} for invalid credentials")
    public void userSeesInvalidCredentialsErrorMessage(String message) {
        String errorMessage = driver.findElement(By.id("errorMessage")).getText();
        assertEquals(message, errorMessage);
    }
}
