package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // 10 seconds explicit wait
    }

    public void navigateToLogin(String loginUrl) {
        if (driver != null) {
            driver.get(loginUrl); // Use a parameter for the login URL
        } else {
            throw new IllegalStateException("WebDriver is not initialized");
        }
    }

    public void enterCredentials(String email, String password) {
        try {
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("loginButton")));

            emailField.sendKeys(email);
            passwordField.sendKeys(password);
            loginButton.click();
        } catch (Exception e) {
            throw new RuntimeException("Error entering credentials: " + e.getMessage());
        }
    }

    public String getSuccessMessage() {
        try {
            WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("successMessage")));
            return successMessage.getText();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching success message: " + e.getMessage());
        }
    }

    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        } else {
            throw new IllegalStateException("WebDriver is not initialized");
        }
    }
}
